"""Create or manage CHANIE prototype users. Run with: python setup_chanie_user.py"""
from __future__ import annotations
import argparse
import hashlib
import getpass
import secrets
import sqlite3
import os
from pathlib import Path
from datetime import datetime, timezone

DB_PATH = Path(os.environ.get("CHANIE_DB_PATH", str(Path(__file__).with_name("chanie_nicu.db")))).expanduser().resolve()
ITERATIONS = 600_000
ROLES = ("admin", "clinician", "nurse", "viewer")

def utc_now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

def hash_password(password: str) -> str:
    if len(password) < 12:
        raise ValueError("Password must be at least 12 characters.")
    salt = secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt, ITERATIONS)
    return f"pbkdf2_sha256${ITERATIONS}${salt.hex()}${digest.hex()}"

def main():
    parser = argparse.ArgumentParser(description="Create a CHANIE local prototype user.")
    parser.add_argument("--username", help="Unique username")
    parser.add_argument("--role", choices=ROLES, default="admin")
    parser.add_argument("--deactivate", action="store_true", help="Deactivate an existing user")
    args = parser.parse_args()
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.execute("PRAGMA busy_timeout=30000")
    conn.execute("""CREATE TABLE IF NOT EXISTS users (
        username TEXT PRIMARY KEY, password_hash TEXT NOT NULL,
        role TEXT NOT NULL CHECK(role IN ('admin','clinician','nurse','viewer')),
        active INTEGER NOT NULL DEFAULT 1, created_utc TEXT NOT NULL)""")
    username = (args.username or input("Username: ")).strip()
    if not username or len(username) > 120:
        raise SystemExit("Username must contain 1-120 characters.")
    existing = conn.execute("SELECT username FROM users WHERE username=?", (username,)).fetchone()
    if args.deactivate:
        if not existing:
            raise SystemExit("User does not exist.")
        conn.execute("UPDATE users SET active=0 WHERE username=?", (username,))
        conn.commit()
        print(f"Deactivated user {username}.")
        conn.close()
        return
    password = getpass.getpass("Password (minimum 12 characters): ")
    confirm = getpass.getpass("Confirm password: ")
    if password != confirm:
        raise SystemExit("Passwords do not match.")
    encoded = hash_password(password)
    if existing:
        conn.execute("UPDATE users SET password_hash=?,role=?,active=1 WHERE username=?", (encoded, args.role, username))
        print(f"Updated user {username} with role {args.role}.")
    else:
        conn.execute("INSERT INTO users(username,password_hash,role,active,created_utc) VALUES(?,?,?,1,?)", (username, encoded, args.role, utc_now()))
        print(f"Created user {username} with role {args.role}.")
    conn.commit()
    conn.close()
    print(f"Database: {DB_PATH}")
    print("Keep the database and backups protected. This local account tool is not a replacement for institutional identity management.")

if __name__ == "__main__":
    main()
